export interface ButtonProps {
  title: string;
  onPress: (params: any) => any;
};
