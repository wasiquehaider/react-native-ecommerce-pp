export declare global {
  namespace ReactNavigation {
    interface RootParamList {
      Products: undefined;
      Cart: undefined;
    }
  }
}
